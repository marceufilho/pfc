# Evaluation Roadmap: from `freeze-v4` to the paper

Date: 2026-11-05. Steps E0–E14, with optional E15. Prospective post-freeze work, not implemented. Each step has a scope, the requirements it satisfies
(`EV-R*` from [evaluation-architecture.md](evaluation-architecture.md)), and a definition of done.
A step is done only when every item in its definition is observed and recorded in `docs/steps/E<n>-*.md`
with the exact commands and results. Steps marked **user** are actions only the user may take.

Estimated total: three to four weeks of harness work plus the held-out and runtime campaigns.

## E0 — Freeze the compiler (user)

Scope: commit the current tree, tag `freeze-v4`, preserve the freeze archive outside Git.

Definition of done:
- [ ] First commit reviewed from the dry-run file list; no secrets, `.venv`, `build/` or binaries.
- [ ] Tag `freeze-v4` created on that commit; commit hash recorded in `docs/FREEZE.md`.
- [ ] `build/freeze/pfc-candidate-20261105.tar.gz` and its SHA-256 copied to durable storage.
- [ ] Full protected and baseline inventories in `validation/freeze/` verified, with additions audited.
- [ ] Clean-validation Docker image and checksum copied with the source archive; local bundle alone is not durable storage.
- [ ] Clone on a second physical machine runs the `docs/FREEZE.md` commands with the specified correctness gates passing; timing and inconclusive solver results may vary and must be retained;
      machine, versions and results recorded.

## E1 — Harness skeleton and CLI approval

Scope: `pfc_eval/` root package (location changed from `pfc/eval/` at the user's request, ADR-0033), `evidence.py`, `stats.py`, import-independence test, `uv run --locked python -m pfc_eval` entry point
approved and implemented without modifying the frozen CLI with `--help`, `Makefile` targets `eval` and `paper` (paper may be a stub that
fails loudly). Requirements: EV-R1, EV-R5, EV-R6, EV-R9, EV-R17–R21.

Definition of done:
- [x] User approval of the standalone evaluation entry point and subcommand list recorded in the step document (docs/steps/E1-harness-skeleton.md, 2026-11-05).
- [x] Test walks the import graph and fails if any `pfc/*` module imports `pfc_eval`.
- [x] `evidence.py` refuses an existing directory, writes `COMPLETE` after execution and seals it in the manifest written last; completion requires both;
      tests for refused, partial and complete runs.
- [x] `stats.py`: Wilson interval, exact binomial bound, seeded cluster bootstrap, sign test, Holm, each
      checked against a published worked example cited in the docstring.
- [x] `evidence.py` writes the D9 layout (raw/, observations.jsonl, schema.json); a test rebuilds
      observations.jsonl from raw/ and asserts byte equality; a schema violation fails the run.
- [x] `make check` passes with the new package; Ruff, Black, mypy clean (856 tests, 2026-11-05).

## E2 — Reference interpreter

Scope: `interpret.py` over typed IR: statements, loops, calls, arrays with declared lengths, overflow and
bounds detection, typed rejections. Requirements: EV-R4, EV-R10, EV-R11.

Definition of done:
- [x] Hand-derived tests for each statement kind, division semantics (truncation, zero, MIN/−1), and each
      rejection type.
- [x] On the six development kernels and the existing seeded cases, the interpreter's observations equal
      `corpus.oracle` for every case (integration test, all six).
- [x] Differential check of the interpreter against the plain build on the six kernels, 1,000 cases each,
      zero disagreements.
- [x] A deliberately overflowing case is rejected with `Overflow`, not executed.
- [x] Step document states the shared-frontend limitation verbatim (docs/steps/E2-reference-interpreter.md, 2026-11-05).

## E3 — REQUIRES-driven generator and general differential test

Scope: `generate.py` with versioned JSON profiles (length range, per-kernel value bounds, boundary cases);
`differential.py` for any subset program with its own file-based driver protocol (ADR-0035; the existing
embedded-initializer driver cannot hold 2^16-element cases). Requirements: EV-R6, EV-R10, EV-R11.

Definition of done:
- [x] Profiles for the six kernels and the eight ports committed with digests; a changed profile is detected.
- [x] Rejection counts by reason recorded per run; boundary cases always present.
- [x] Six-kernel run (plus the eight ports): 1,000 accepted cases each, three builds compared pairwise and against the interpreter,
      zero failures; results byte-equal on rerun with the same seed except timing fields.
- [x] Mutant check: the historical delete-without-proof mutant is detected by the general harness.
- [x] `uv run --locked python -m pfc_eval differential kernels --output NEW` produces a sealed directory with Table II rows (bench/eval/differential-20261105, 2026-11-05).

## E4 — Per-conjunct break-it

Scope: `conjuncts.py`: split each `REQUIRES` conjunction, drop one conjunct at a time, compare per-site
verdicts and emitted executable C; `SEPARATED` column. Requirements: EV-R12.

Definition of done:
- [x] Tests on a two-conjunct contract: dependent conjunct → site loses proof and guard reappears;
      independent conjunct → identical verdicts and C.
- [x] Six kernels: sensitivity and specificity computed; outcomes consistent with `demo/validation-v4`
      whole-contract break-it where the contract has one conjunct.
- [x] `SEPARATED` removal reported as restrict withdrawal, never as a bounds failure (bench/eval/conjuncts-20261105, 2026-11-05; ADR-0036).

## E5 — Systematic injection and reproduction classifier

Scope: `inject.py`: 20 candidate mutations per loop from fixed operators, independently classified, admission through `admit()`,
classification of counterexample models as entry-state or abstract, reproduction via `replay.py`.
Requirements: EV-R13, EV-R14.

Definition of done:
- [x] Operator set and seed committed; generated set for the six kernels saved and hashed.
- [x] Independently established false candidates all rejected; valid/insufficient/unclassified mutations
      separately counted. Literal `false` and curated near-miss included; a dropped conjunct is not presumed false.
- [x] Every reconstructible entry-state model reproduces (trap or violation observed); abstract and unreconstructible models counted separately (bench/eval/inject-20261105, 2026-11-05; ADR-0037).
- [x] A fabricated "reproducible" model that does not reproduce is reported as a discrepancy requiring diagnosis in tests.

## E6 — Houdini baseline (B1)

Scope: `houdini.py` per §3.4 D4 of the architecture. Requirements: EV-R14.

Definition of done:
- [x] Unit test: two-conjunct fixpoint with one falsified conjunct, hand-derived (three rounds: the preservation refutation waits for the initiation-false candidate to leave the conjunction).
- [x] Six development kernels: B1 success recorded per loop with rounds, queries and solver time (bench/eval/houdini-20261105: 5/6 at the pre-registered bound; matvec reaches a fixpoint only at round 10, bench/eval/houdini-20261105-rounds10).
- [x] Conjunct queries preserve the full current induction hypothesis; SAT removals and timeout/unknown
      handling tested. Round-limit stops are distinguished from fixpoints; query costs are recorded.
- [x] Family definition in code matches the pre-registration text character for character (test; ADR-0039).

## E7 — Robustness variants and metamorphic check

Scope: `robustness.py`: α-renaming, declaration reordering, commutative operand swaps; verdict and C
comparison under an explicit site mapping/normalization. Shared with the E3 obfuscation stratum. Requirements: EV-R12.

Definition of done:
- [x] Each transformation has stated semantic side conditions and hand-derived examples (ADR-0040); 100-case
      comparisons provide empirical validation, not a proof. Renamed C is not expected byte-identical.
- [x] Six kernels × 10 variants (plus the eight ports): differences reported as brittleness with the variant saved (bench/eval/robustness-20261105: 0 brittle, 0 divergent).
- [x] Obfuscation function (`robustness.obfuscate`) ready for the Code2Inv/SV-COMP ported stratum; its application is E10.

## E8 — Solver-budget sweep

Scope: `sweep.py` over `pfc check` at 1, 2, 5, 10, 30, 60 s and over the new campaign runner `pfc_eval/wp.py` with the same
budgets; the fixed baseline oracle runner and manifest stay unchanged. Requirements: EV-R6, EV-R9.

Definition of done:
- [x] Each budget runs in a fresh process with a fresh cache; verified by query identities in output (103/103 pfc obligations carry six distinct query ids).
- [x] Figure 2 data for the six kernels and eight ports, both tools, sealed (bench/eval/sweep-20261105, 2026-11-05; ADR-0041).

## E9 — Mutation runner

Scope: `mutate.py`: fixed operators on `vc.py`, `wp.py`, `authorization.py`, `emit.py` (and, for the harness
itself, `interpret.py`, `stats.py`); layered execution; kill matrix. Requirements: EV-R6.

Definition of done:
- [x] 30–50 mutants generated with a committed seed; mutant diffs saved (40 compiler + 10 harness, seed 0; `mutants/<id>.diff` in bench/eval/mutate-20261105b; ADR-0042).
- [x] Layers run in order unit → golden → differential → break-it → injection → oracle (survivors only).
- [x] Golden-only kills reported separately (emit-06); survivors hand-classified in docs/steps/E9-mutation-runner.md.
- [x] Mutation score with Wilson interval ≥ 0.90 or the shortfall documented: first campaign 0.75 [0.60, 0.86] documented with its survivors; after eight gap tests the same 40 mutants give 0.90 [0.77, 0.96] (four equivalent survivors), harness 10/10.

## E10 — Proposer conditions and open-weight endpoint

Scope: new `pfc_eval/proposer.py` task runner with L2 prompt construction and new evaluation-only service
settings/transport for L3. Existing curated experiment, Settings and admission files stay unchanged.
Record model identity and available weights hash; add the Code2Inv/SV-COMP port script. Requirements: EV-R7.

Definition of done:
- [x] L2 verified by transcript inspection: no counterexample text in any L2 prompt (`proposer.contains_feedback`, tests/eval/test_eval_proposer.py; ADR-0043).
- [x] L3 adapter tested with a mocked endpoint; no secret in argv; base URL recorded in evidence (pfc_eval/adapters.py, tests/eval/test_eval_adapters.py).
- [x] 30 ported public loops committed with the port script and per-loop provenance (bench/external/zilu, zilu-obfuscated; pfc_eval/ports.py; PROVENANCE.json).
- [x] `--replay` reproduces (6, 6, 6) on the archived development transcripts with zero requests (tests/eval/test_eval_proposer_integration.py over bench/proposals/g2-astra-20261105).

## E11 — Runtime harness

Scope: `runtime.py`: three interleaved blocks of 10 runs after 3 warm-ups, perf or cachegrind counters,
vectorization remarks, per-kernel rows, log-scale ratios. Requirements: EV-R16.

Definition of done:
- [x] Dry run lists the full schedule; real run on one kernel verifies interleaving from timestamps (tests/eval/test_eval_runtime_integration.py; ADR-0044).
- [x] Governor recorded; run labelled exploratory if not `performance` (development machine: powersave → exploratory).
- [x] Counter tool recorded; cachegrind used when perf is unavailable (neither installed here: `counter_tool = unavailable` in every row).
- [x] Table V and Figure 5 data sealed with absolute medians and ratios (bench/eval/runtime-20261105, exploratory; thesis/generated/table-V-runtime.md, figure-5-runtime-ratios.csv). The designated machine of E14 must repeat it under `performance` with a counter.

## E12 — Held-out corpus and sealing (user with advisor)

Scope: `heldout.py seal|verify`; held-out kernels written from the fixed name list after `freeze-v4` by the
advisor or a colleague, with the B1 family and the template-hard requirement in hand; ACSL written for each
by the recorded procedure. Requirements: EV-R15.

Definition of done:
- [ ] Every name passed `pfc ir` before sealing; replacements recorded. (Tooling ready: `heldout seal` runs the acceptance check and records replacements in SEALING.json, ADR-0045; no held-out kernel exists yet — user with advisor.)
- [ ] At least half the loops have a hand invariant outside the B1 family (syntactic check recorded). (Checked and recorded by `heldout seal`; aborts below one half.)
- [ ] `HELDOUT.sha256` and `canaries.json` committed before any experiment reads `heldout/`. (Written by `heldout seal`; every campaign verifies them through campaign.run_command.)
- [ ] Held-out ACSL and hashes stored in a new campaign profile, outside the protected baseline fixtures;
      non-executing preview of the new oracle runner passes.
- [ ] No proposer, Houdini or oracle run has touched the held-out set before sealing (log statement). (`--untouched` statement recorded verbatim in SEALING.json.)

## E13 — `make paper` and tag `eval-v1` (user tags)

Scope: `tools/paper.py` and `tables.py` build every table and figure from a configured list of sealed
evidence directories; the final design/architecture and disclosed pre-outcome amendments versioned; tag `eval-v1`. Requirements: EV-R8.

Definition of done:
- [x] `make paper` regenerates all development-set tables byte-identically on two consecutive runs (22 files; `make paper PAPER_ARGS=--check` → 0 problems; docs/steps/E13-paper-tables.md).
- [x] A test fails if any paper table differs from the regenerated one (tests/eval/test_eval_tables.py::test_committed_generated_tables_match_a_fresh_build; `make paper PAPER_ARGS=--check`).
- [x] Both inventories match `freeze-v4`; the complete path diff and reviewed additions are saved (`make paper PAPER_ARGS=--paths` → paper/PATH-DIFF.md: protected 40/40, baseline 194/194; the tag itself is still absent).
- [ ] All design amendments since `freeze-v4`, model/profile/budget settings and power-analysis assumptions
      are recorded before held-out outcomes; the final protocol is fixed at `eval-v1`. (Draft record: paper/AMENDMENTS.md, 14 items, three user decisions open.)
- [ ] Tag `eval-v1` created by the user; hash recorded. (User-owned; `freeze-v4` is also still absent in this clone.)

## E14 — Evaluation campaign and deviations

Scope: run every experiment once on the held-out set in the `eval-v1` configuration; run the runtime
campaign on the designated machine; write the Deviations paragraph.

Definition of done:
- [ ] Each experiment has a sealed directory with `COMPLETE`, environment, seeds and configuration. (Development-set campaigns: yes, bench/eval/*; held-out: not run — no held-out kernels exist; plan in pfc_eval/campaign_plan.py, docs/steps/E14-campaign-plan.md.)
- [ ] Held-out experiments ran exactly in one campaign per condition, with its pre-registered R runs; the log shows no re-prompting. (`campaign_plan.execute` refuses existing outputs and logs every step once; not executed.)
- [ ] Every off-diagonal cell has evidence for its diagnosis or an explicit unresolved-cause status;
      unresolved cases do not meet the zero-unclassified target. Raw verdicts remain unchanged.
- [ ] Deviations paragraph lists every threshold, kernel or protocol change with the original value. (Draft inputs: paper/AMENDMENTS.md; template in docs/steps/E14-campaign-plan.md.)
- [ ] `make paper` at `eval-v1` plus the evidence directories regenerates every number in the paper.
- [ ] Archive of the tag, `bench/eval/`, `logs/llm/` and `heldout/` deposited with a DOI.

## E15 — Optional: model comparison and cost study (only if time allows)

Scope: design §13. Run L1 with each pre-registered model and effort level on the primary held-out split,
once each; `heldout-B` sealed for any later exploratory selection; Table IX and Figure 8. Requirements:
EV-R6, EV-R7, EV-R15.

Definition of done:
- [ ] Model list with identifiers, snapshot status, settings and adapter appended to design §13.2 before
      `eval-v1`; models added later are labelled exploratory in every table.
- [ ] `heldout-B` sealed with hash and canaries before any model-selection run.
- [ ] Frozen prompt unchanged across models; any format adaptation saved as a diff and disclosed.
- [ ] Per model and effort: R = 5 runs, all transcripts cached, replay reproduces with zero requests.
- [ ] Price sheet with date stored in the evidence; tokens reported as primary cost unit.
- [ ] Table IX and Figure 8 regenerated by `make paper`; intervals on both axes of the front.
- [ ] If not run: one sentence in the paper stating that §13 was pre-registered and not executed.

## Dependencies

```text
E0 ─▶ E1 ─▶ E2 ─▶ E3 ─▶ E4
             │          ├─▶ E5
             │          └─▶ E7 ─▶ E10 (ports)
             └─▶ E6
E1 ─▶ E8, E9, E11
E2..E11 ─▶ E13 ─▶ E14 ─▶ E15 (optional)
E12 (parallel from E0; sealed before E14)
```

E2 and E3 are the critical path: without them the held-out set receives no differential evidence.
E12 starts the day after E0 and must not wait for the harness; sealing happens when E13 is ready.

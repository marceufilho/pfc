# Evaluation Architecture: requirements and implementation of the `pfc` evaluation harness

Date: 2026-11-05. Companion to [experimental-design.md](experimental-design.md) (the pre-registration, which
says *what* is measured and *how it is analysed*) and [evaluation-roadmap.md](evaluation-roadmap.md) (the
order of work with definitions of done). This document says *how the harness is built* so that the
numbers in the paper are reproducible, independent of the compiler under test, and auditable.

## 1. Purpose and position

The compiler under evaluation is the tree tagged `freeze-v4`. The harness is evaluation infrastructure
added between `freeze-v4` and `eval-v1`. It reads the compiler through its public Python API and CLI and
is never imported by an existing compiler module. The protected inventory in
`validation/freeze/protected.sha256` covers all existing package files, frontend headers and locked
configuration. Baseline tests/oracle fixtures are separately inventoried. Both inventories must remain
byte-identical; additions and other permitted changes are published as a complete diff. This is a
prospective architecture, not implemented functionality or permission to begin the evaluation campaign.

Three sources frame the architecture: the evaluation harness is distinct from the system under test and
pins its task set, trial count and graders (Anthropic, *Demystifying Evals for AI Agents*, 2026; Biderman
et al., *Lessons from the Trenches*, 2024); every published number must be regenerable by a script
(Reuel et al., *BetterBench*, 2024); and the methodology must avoid the benchmarking flaws catalogued by
van der Kouwe et al. (2018). The compiler's own rules in `CLAUDE.md` continue to apply: fail closed,
never fabricate evidence, never overwrite sealed directories, never commit or tag on the user's behalf.

## 2. Requirements

Identifiers `EV-R*` are referenced by the roadmap. "Must" is a requirement for `eval-v1`.

### 2.1 Independence and trust

- **EV-R1** The harness package must not be imported by any module under `pfc/` except itself. A test
  asserts this by walking the import graph.
- **EV-R2** The harness must not grant proof authority. It consumes `smt.CheckReport`, `emit.Emission` and
  `authorization` decisions; it never constructs verdicts, never writes to the solver cache, and never
  edits evidence it did not produce.
- **EV-R3** Every grader is computational: Z3 verdicts, compiled binaries, Frama-C/WP goals, byte
  comparison, deterministic instruction counts. No LLM-as-judge anywhere.
- **EV-R4** The reference interpreter shares parsing/lowering, typed IR and target metadata; it does not
  reuse the VC generator, solver translation, emitter or replay evaluator to compute observations. The paper names this shared component explicitly.

### 2.2 Reproducibility

- **EV-R5** Every experiment writes to a new, exclusive output directory and ends by sealing a manifest of
  SHA-256 digests over every file it wrote. Existing directories are refused. Partial runs are preserved
  and marked incomplete; absence of `COMPLETE` is not success.
- **EV-R6** Every stochastic component (input generation, mutant selection, bootstrap, run order, LLM
  sampling) takes an explicit seed recorded in the output. Rerunning with the same seed and inputs
  regenerates identical evidence except for timing fields and service responses.
- **EV-R7** All LLM requests and responses are cached under the existing research-transcript mechanism;
  every proposer experiment supports `--replay` with zero network requests. Replay is labelled replay.
- **EV-R8** `make paper` regenerates every table and figure in the paper from sealed evidence directories
  listed in one configuration file. No number is typed by hand. A test diffs the regenerated tables against
  the committed ones.
- **EV-R9** Environment metadata (Python, Z3, clang, Frama-C image digest, CPU model, governor, kernel,
  perf availability) is recorded in every evidence directory using the existing `environment` module.

### 2.3 Soundness of the evaluation itself

- **EV-R10** Differential inputs must satisfy `REQUIRES` *and* execute without undefined behavior. The
  interpreter applies the IR operation type and target limits, including expression-only `int`,
  conversions, short-circuiting, division and relevant memory preconditions; rejected cases are counted
  and reported, never silently dropped.
- **EV-R11** Agreement requires complete observations from all compared binaries. Timeout, crash, signal or
  truncated output is a failure of the case, not agreement.
- **EV-R12** Break-it "changed/unchanged" is defined on per-site verdicts and executable emitted C, never
  on obligation IDs. The `SEPARATED` consequence (restrict-fact withdrawal, ADR-0017) is a separate column.
- **EV-R13** Counterexample reproduction is attempted only for models that denote entry states (initiation
  and entry-derived bounds models). Others are counted as abstract. A model classified as reproducible that fails to
  reproduce is a discrepancy requiring diagnosis of reconstruction, harness and compiler semantics.
- **EV-R14** The Houdini baseline uses the same `admit()` path, the documented per-query budget and the same final acceptance
  definition as the LLM conditions. Query counts, total solver time and refinement-round budgets are
  reported separately. The candidate family is fixed in the pre-registration and in code.
- **EV-R15** The held-out corpus is sealed by hash before its first run. The harness refuses to run a
  held-out experiment if the hash file is missing or does not match, and records the hash in the output.
- **EV-R16** Benchmarking-crime guards for runtime: absolute medians stored beside ratios; aggregation
  across runs uses the log scale; per-kernel rows are always emitted; any slowdown is reported.

- **EV-R21** Every experiment stores two layers: immutable **raw records** (one JSON file per observation,
  sealed) and a derived **tidy table** (`observations.jsonl`, one row per unit of analysis, fixed documented
  schema, regenerable from the raw records by `tables.py`). Analysis reads tidy tables only; `tables.md` is
  rendering, never a data source. Every row carries provenance columns.

### 2.4 Engineering

- **EV-R17** Pure functions for all transformations (candidate enumeration, conjunct splitting, mutant
  generation, statistics). Subprocess, solver, filesystem and network stay at explicit boundaries that
  tests can inject.
- **EV-R18** pytest-driven TDD for every production-path change; hand-derived expectations for statistics
  (Wilson, bootstrap, sign test) checked against published worked examples.
- **EV-R19** Ruff, Black, mypy clean; the harness is in the `make check` path.
- **EV-R20** One documentation step report per roadmap step in `docs/steps/`, following the existing format.

## 3. Architecture

### 3.1 Package layout

Amendment 2026-11-05 (E1, [ADR-0033](docs/decisions/0033-evaluation-harness-location-and-skeleton.md)):
the user chose a **separate root package `pfc_eval/`** instead of `pfc/eval/`; the module list below is
unchanged, the entry point is `python -m pfc_eval`, and no protected path receives new files. Implemented
at E1: `__init__.py`, `__main__.py`, `cli.py`, `evidence.py`, `stats.py`; the rest remains prospective.

```text
pfc_eval/                       evaluation harness; never imported by pfc/*
    __init__.py
    generate.py                 REQUIRES-driven rejection sampler for arbitrary subset programs
    interpret.py                reference interpreter over mathematical integers with overflow detection
    differential.py             three-build comparison for any subset program (generalises difftest.py)
    conjuncts.py                per-conjunct REQUIRES ablation and verdict/C comparison
    inject.py                   systematic false-invariant generator and reproducibility classifier
    mutate.py                   source mutants of the trusted files and layered kill matrix
    robustness.py               semantics-preserving variants (α-rename, reorder, commute) and verdict equality
    houdini.py                  B1 template baseline over admit()
    sweep.py                    solver-budget curve for pfc/Z3 and WP/Alt-Ergo
    heldout.py                  sealing, canary and hash verification
    runtime.py                  interleaved blocks, cachegrind/perf counters, vectorization remarks
    stats.py                    Wilson, seeded cluster bootstrap, exact sign test, Holm
    evidence.py                 exclusive output directories, manifests, COMPLETE marker (wraps report.seal)
    tables.py                   paper tables and figure data from sealed evidence
    __main__.py                 standalone `python -m pfc_eval` entry point (implemented at E1)
    cli.py                      evaluation argument parsing only (approved subcommand list, E1)
    proposer.py                 new task runner; calls frozen admit() with complete candidate lists
    adapters.py                 evaluation-only service boundary and independently recorded settings
    wp.py                       new configurable WP campaign runner; preserves the old fixed experiment
tools/frama_oracle.py           unchanged fixed 14-function experiment; parsers reusable by new runner
tools/paper.py                  `make paper`: calls tables.py over the configured evidence list
heldout/                        sealed kernels, HELDOUT.sha256, canaries.json
bench/eval/<experiment>-<date>/ sealed evidence directories
```

### 3.2 Reuse of existing modules

| Existing | Used by | How |
| --- | --- | --- |
| `parse.py`, `lower.py`, `ir.py` | all | typed IR as the only program representation |
| `replay.py` | entry-model replay only | keep it separate from the independent reference interpreter; it imports compiler VC/solver logic |
| `difftest.py`, `corpus.py` | `differential.py` | driver generation, process boundary, full-state comparison; the six profiles remain the regression targets |
| `breakit.py` | `conjuncts.py` | `check_kernel` logic reused on split contracts |
| `propose/invariants.py::admit`, `strip` | `houdini.py`, `inject.py` | single admission path for every candidate |
| `propose/experiment.py` | historical replay | stays unchanged; new task/condition orchestration lives in `pfc_eval/proposer.py` |
| `propose/llm.py` | current curated transport | stays frozen, including its restricted Settings; new evaluation settings/endpoint transport belong in `pfc_eval/adapters.py` |
| `smt.py` | `sweep.py` | query identity already includes the timeout |
| `authorization.py`, `emit.py` | `conjuncts.py`, `robustness.py` | per-site decisions and emitted C |
| `report.py` | `evidence.py`, `tables.py` | sealing, loading, schema-2 summaries |
| `bench.py`, `drivers.py`, `environment.py` | `runtime.py` | hyperfine boundary, drivers, metadata |

### 3.3 Data flow

```text
kernel.c ──parse/lower──▶ ir.Program
   │                        ├──▶ generate.py ──▶ cases ──▶ interpret.py ──▶ expected state / reject(UB)
   │                        │                                   │
   │                        │                 emit plain/checked/verified ──▶ build ──▶ run cases
   │                        │                                   └──▶ differential.py ──▶ Table II
   │                        ├──▶ conjuncts.py ──▶ check+emit per ablation ──▶ sensitivity/specificity
   │                        ├──▶ inject.py ──▶ admit() ──▶ rejection; replay.py on entry models
   │                        ├──▶ houdini.py ──▶ admit() ──▶ B1 success@5
   │                        ├──▶ eval/proposer.py ──▶ L1/L2/L3 success@5 (cached transcripts)
   │                        ├──▶ sweep.py ──▶ check at 1..60 s; eval/wp.py at 1..60 s ──▶ Figure 2
   │                        └──▶ robustness.py ──▶ variants ──▶ verdict/C equality
   mutate.py ──▶ mutant trees ──▶ layered test run ──▶ kill matrix ──▶ Figure 6
   runtime.py ──▶ blocks × builds × ablations ──▶ Table V, Figure 5
   every experiment ──▶ evidence.py (exclusive dir, manifest, COMPLETE) ──▶ tables.py ──▶ make paper
```

### 3.4 Key design decisions

**D1. Independent reference interpreter for the supported subset.** For held-out kernels no executable hand-written oracle is assumed.
The interpreter executes the IR over unbounded integers, checks every read/write index against the declared
length, checks every C arithmetic result against its IR type
and target range (annotations use their separately documented mathematical semantics), and returns either the full observed state
or a typed rejection (`OutOfBounds`, `Overflow`, `DivisionByZero`, `PreconditionViolated`). On the six
development kernels it must reproduce the existing `corpus.oracle` verdicts on the existing generated cases
before it is trusted elsewhere. Its independence is from the VC generator, emitter and solver, not from the
frontend/IR and target metadata; this is stated wherever the oracle is cited. Do not reuse
`replay.evaluate`, VC terms, emission logic or solver translations to compute reference observations.
Unsupported semantics, execution fuel exhaustion and missing observations produce explicit inconclusive
or rejected cases, never silently accepted inputs.

**D2. REQUIRES-driven generation by rejection.** The generator reads parameter types, array/length links and
`REQUIRES` from the IR, samples lengths log-uniformly in a configured range, samples scalars and array
contents within per-kernel value bounds given in a reviewed JSON profile, and keeps a case only if the
interpreter accepts it. The number of rejections per reason is recorded. The ten boundary cases per kernel
are specified in the same profile. Profiles are versioned and hashed like `corpus.PROFILES`.

**D3. One admission path.** B1, L1, L2, L3 and injection all call `propose.invariants.admit`. Success is
defined once by the frozen `Admission.accepted` result for a complete function task and invariant list.
This includes all-loop admission and guard removal, not just a selected loop formula. False/unknown/error
results cannot be relabelled success. The new arbitrary-task runner must explicitly scope transcript
authorization; existing curated `synthesize()`/Settings are not a general-purpose endpoint API.

**D4. Bounded Houdini-style elimination over a fixed family.** Enumerate the fixed candidates over
in-scope typed scalar bindings. Check initiation under the entry context and each candidate's preservation
under the **whole current conjunction** at the loop head. Drop only candidates refuted by a genuine SAT
model of the corresponding implication; unknown/timeouts do not establish falsity. Repeat after removals,
up to five refinement rounds; a round limit is not a fixpoint. A failed downstream bounds goal does not
by itself identify an invalid invariant conjunct. Models need not expose a directly executable post-state;
the candidate-to-query correspondence must be explicit and tested, not inferred from missing model fields.
Final success always goes through unchanged `admit()`; exploratory candidate queries confer no authority.
Before `eval-v1`, freeze candidate counts, query accounting and any aggregate time cap. Report resource
use separately from the five complete LLM proposals; equal query timeouts alone do not equalize total cost.

**D5. Held-out sealing.** `heldout.py seal` first embeds the random canary comments and writes `canaries.json`, then hashes
the final kernel bytes and companion metadata into `HELDOUT.sha256`. No source changes follow hashing. `heldout.py verify` is
called by every experiment that touches `heldout/`; a mismatch aborts before any solver or service call.

**D6. Evidence directories.** Every experiment writes configuration, environment, raw records and derived outputs. On completed
execution it writes `COMPLETE`, then seals all files including that marker with `manifest.json` last.
Completion requires both the marker and a valid closed manifest; a marker alone is insufficient.
A crash before sealing leaves an incomplete run, even if the marker exists. `evidence.py` wraps the
existing `report.seal`/`report.load` and refuses non-empty destinations.

**D7. Statistics in pure Python.** Wilson interval, exact binomial bound, seeded cluster bootstrap over
kernels with B = 2,000, exact sign test, Holm correction. No numpy or scipy dependency enters the lock; each
function is checked against a worked example from a textbook or published table.

**D8. A separate evaluation entry point.** Approved and implemented at E1 as `uv run --locked python -m pfc_eval` (originally proposed as `python -m pfc.eval`) with the planned
subcommands, leaving `pfc/cli.py` and the package entry point unchanged. Adding `pfc eval` to the frozen CLI
would violate EV-R1; it is not part of this plan. Future implementation and Makefile targets need approval
at E1. Parsing/report-only commands need no compiler or solver flags; each subcommand documents its actual
options. All writing commands require a new output destination and support a non-writing preview.

The existing `tools/frama_oracle.py` fixes 14 positives, six controls, source hashes and a ten-second budget.
It is not a generic held-out/sweep interface. A new `pfc_eval/wp.py` must accept explicit, sealed campaign
profiles and reuse the reviewed verdict parsing where appropriate; do not modify the baseline manifest or
pretend the current runner accepts unsupported flags. Secondary prover images get separate identities.

**D9. Data layout for later analysis.** Each evidence directory has the same shape:

```text
bench/eval/<experiment>-<date>/
    configuration.json      seeds, budgets, profile digests, model settings, held-out hash
    environment.json        pfc env --json output plus tag, commit, trusted-file hashes
    raw/<unit>/<shard>.jsonl write-once records, one line per observation, one shard per kernel (ADR-0038; the E1–E5 campaigns used one file per record)
    observations.jsonl      tidy table: one row per unit of analysis, derived from raw/
    schema.json             column names, types, units and allowed values for observations.jsonl
    summary.json            aggregates with intervals, derived from observations.jsonl
    tables.md               rendering for humans; not an input to anything
    COMPLETE                experiment execution completed; included in the manifest
    manifest.json           written last; SHA-256 of every other file, including COMPLETE
```

The unit of analysis is the row of `observations.jsonl` and is fixed per experiment:

| Experiment | One row is | Key columns besides provenance |
| --- | --- | --- |
| E1.1 differential | kernel × case | case_id, accepted/rejected_reason, lengths, agreement, failure_kind |
| E1.2 break-it | kernel × conjunct | conjunct_text, dependent, proof_lost, guard_restored, restrict_withdrawn, c_identical |
| E1.3 injection | loop × injected invariant | operator, rejected, verdict, model_class (entry/abstract), reproduced |
| E1.4 mutation | mutant × layer | operator, location, killed, layer, equivalent |
| E1.5 robustness | kernel × variant | transformation, verdicts_identical, c_identical |
| E2 capability | function × obligation × budget | kind, status, solver_ms, tool (pfc/wp), budget_s |
| E2 oracle | function × property | pfc_status, wp_verdict, cell (both/pfc-only/wp-only/neither), adjudication |
| E3 proposer | function task × condition × run × attempt | model, effort, success, rejection_class, tokens_in/out/reasoning, latency_ms |
| E4 runtime | kernel × build × block × run | wall_ms, instructions, counter_tool, vectorized, ablation |
| §13 models | function task × model × effort × run | as E3 plus price_sheet_date, usd |

Provenance columns present in every row: `experiment`, `evidence_dir`, `tag`, `commit`, `seed`, `timestamp`,
`vc_model`, `solver_version`, `clang`, and for proposer rows `protocol`, `model`, `snapshot_status`. Column
names are snake_case, units are in the name (`_ms`, `_s`, `_usd`), booleans are JSON booleans, missing is
`null` with a reason column where it matters (`rejected_reason`, `not_run_reason`). Long format only: one
measurement per row, never one column per condition. `stats.py` and `tables.py` consume `observations.jsonl`
from one or more sealed directories, so cross-run analysis is a concatenation, and a notebook or R session
can read the same files without the harness. Raw records exist so a schema mistake can be repaired by
regenerating the tidy table, never by editing sealed data.

### 3.5 Threats the architecture itself introduces, and their controls

| Threat | Control |
| --- | --- |
| Interpreter bug silently weakens RQ1 | Regression against the six existing oracles and cases; mutation testing includes `interpret.py`; the interpreter is itself differential-tested against the plain build on development kernels |
| Generator never produces hard cases | Rejection counts and length/value histograms are part of Table II; boundary cases are mandatory |
| Bounded baseline weaker than full Houdini | Five rounds may stop before a fixpoint; report limits and actual query costs, and do not claim equivalence to the published algorithm |
| Harness drift between tags | Hash list of trusted files; harness-only diff published |
| Evidence alteration | Closed manifests detect changes relative to recorded hashes; they do not authenticate an origin that controls both data and manifest |

## 4. Testing strategy for the harness

| Layer | What | Where |
| --- | --- | --- |
| Unit | pure functions: enumeration, splitting, statistics, parsing of WP/perf/cachegrind output | `tests/eval/test_*.py` |
| Hand-derived | interpreter results on small programs; Wilson/bootstrap on textbook examples; Houdini fixpoint on a two-conjunct case | same |
| Integration | real Z3 and clang on the six kernels: generator+interpreter reproduce existing oracle verdicts; B1 solves the six; conjunct ablation reproduces `demo/validation-v4` break-it outcomes | `tests/eval/test_*_integration.py` |
| Negative | refused existing output; missing/mismatched held-out hash; UB case rejected; incomplete binary output is failure; abstract model not reproduced | same |
| Mutation of the harness | `mutate.py` run on `interpret.py` and `stats.py` once, reported in the step document | `docs/steps/` |

## 5. What is explicitly out of scope

Language extensions, a second optimizing IR, Alive2, cvc5, quantified specifications, hosted CI as a
claim, and any change to the trusted files. If harness work uncovers a compiler defect, the fix is a new
candidate commit and tag, and both the before and after tables are published.

## 6. Reading order

1. [experimental-design.md](experimental-design.md), sections 1–3 and 8.
2. This document, sections 2 and 3.4.
3. [evaluation-roadmap.md](evaluation-roadmap.md).
4. [docs/FREEZE.md](docs/FREEZE.md) for the tag handoff.
5. Existing modules in the order of §3.2.
